create
    definer = root@localhost procedure findAllCustomers()
BEGIN

    SELECT * FROM customers where customerNumber = 175;

END;

