create
    definer = root@localhost procedure all_info()
BEGIN
    SELECT * FROM product;
end;

