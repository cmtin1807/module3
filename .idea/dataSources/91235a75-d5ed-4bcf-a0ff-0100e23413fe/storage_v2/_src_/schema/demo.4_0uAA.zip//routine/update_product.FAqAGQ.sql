create
    definer = root@localhost procedure update_product(IN p_product_id int, IN p_product_code varchar(255),
                                                      IN p_product_name varchar(255), IN p_product_price int,
                                                      IN p_product_amount int, IN p_product_description varchar(255),
                                                      IN p_product_status bit)
BEGIN
    UPDATE product
    SET product_code = p_product_code,
        product_name = p_product_name,
        product_price = p_product_price,
        product_amount = p_product_amount,
        product_description = p_product_description,
        product_status = p_product_status
    WHERE product_id = p_product_id;
END;

