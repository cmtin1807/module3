create
    definer = root@localhost procedure add_product(IN p_product_code varchar(255), IN p_product_name varchar(255),
                                                   IN p_product_price int, IN p_product_amount int,
                                                   IN p_product_description varchar(255), IN p_product_status bit)
BEGIN
    INSERT INTO product(product_code, product_name, product_price, product_amount, product_description, product_status)
    VALUES (p_product_code, p_product_name, p_product_price, p_product_amount, p_product_description, p_product_status);
END;

