create
    definer = root@localhost procedure remove_product(IN p_product_id int)
BEGIN
    DELETE FROM product Where product_id = p_product_id;

end;

