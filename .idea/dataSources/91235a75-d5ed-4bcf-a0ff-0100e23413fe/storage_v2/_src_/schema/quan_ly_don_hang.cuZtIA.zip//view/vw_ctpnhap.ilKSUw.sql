create definer = root@localhost view vw_ctpnhap as
select `pn`.`so_phieu_nhap`                AS `Số phiếu nhập hàng`,
       `ctn`.`id_vat_tu`                   AS `Mã vật tư`,
       `ctn`.`sl_nhap`                     AS `Số lượng nhập`,
       `ctn`.`dg_nhap`                     AS `Đơn giá nhập`,
       (`ctn`.`sl_nhap` * `ctn`.`dg_nhap`) AS `Thành tiền nhập`
from (`quan_ly_don_hang`.`ct_phieu_nhap` `ctn` join `quan_ly_don_hang`.`phieu_nhap` `pn`
      on ((`ctn`.`id_phieu_nhap` = `pn`.`id_phieu_nhap`)));

