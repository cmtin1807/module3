create definer = root@localhost view vw_ctpnhap_vt_pn_dh as
select `pn`.`so_phieu_nhap`                AS `Số phiếu nhập hàng`,
       `pn`.`ngay_nhap`                    AS `Ngày nhập hàng`,
       `pn`.`id_don_hang`                  AS `Số đơn đặt hàng`,
       `ddh`.`id_nha_cc`                   AS `Mã nhà cung cấp`,
       `vt`.`id_vat_tu`                    AS `Mã vật tư`,
       `vt`.`ten_vat_tu`                   AS `Tên vật tư`,
       `ctn`.`sl_nhap`                     AS `Số lượng nhập`,
       `ctn`.`dg_nhap`                     AS `Đơn giá nhập`,
       (`ctn`.`sl_nhap` * `ctn`.`dg_nhap`) AS `Thành tiền nhập`
from (((`quan_ly_don_hang`.`ct_phieu_nhap` `ctn` join `quan_ly_don_hang`.`phieu_nhap` `pn`
        on ((`pn`.`id_phieu_nhap` = `ctn`.`id_phieu_nhap`))) join `quan_ly_don_hang`.`vat_tu` `vt`
       on ((`vt`.`id_vat_tu` = `ctn`.`id_vat_tu`))) join `quan_ly_don_hang`.`don_dat_hang` `ddh`
      on ((`ddh`.`id_don_hang` = `pn`.`id_don_hang`)));

