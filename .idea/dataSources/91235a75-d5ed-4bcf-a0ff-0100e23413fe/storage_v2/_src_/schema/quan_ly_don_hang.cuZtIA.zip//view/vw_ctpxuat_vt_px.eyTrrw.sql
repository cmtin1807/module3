create definer = root@localhost view vw_ctpxuat_vt_px as
select `px`.`id_phieu_xuat`  AS `Số phiếu xuất hàng`,
       `px`.`ten_khach_hang` AS `Tên khách hàng`,
       `vt`.`ma_vat_tu`      AS `Mã vật tư`,
       `vt`.`ten_vat_tu`     AS `Tên vật tư`,
       `ctpx`.`sl_xuat`      AS `Số lượng xuất`,
       `ctpx`.`dg_xuat`      AS `Đơn giá xuất`
from ((`quan_ly_don_hang`.`ct_phieu_xuat` `ctpx` join `quan_ly_don_hang`.`phieu_xuat` `px`
       on ((`ctpx`.`id_phieu_xuat` = `px`.`id_phieu_xuat`))) join `quan_ly_don_hang`.`vat_tu` `vt`
      on ((`ctpx`.`id_vat_tu` = `vt`.`id_vat_tu`)));

