create
    definer = root@localhost procedure sp_TongTienXuatVatTu(IN p_id_vat_tu int, OUT p_tong_tien_xuat int)
BEGIN
    SELECT SUM(ct_phieu_xuat.sl_xuat*ct_phieu_xuat.dg_xuat)
    into p_tong_tien_xuat
        FROM ct_phieu_xuat
            where id_vat_tu = p_id_vat_tu;
end;

