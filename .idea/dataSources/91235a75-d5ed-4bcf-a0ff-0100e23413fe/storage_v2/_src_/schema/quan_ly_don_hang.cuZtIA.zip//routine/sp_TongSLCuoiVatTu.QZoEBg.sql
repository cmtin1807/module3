create
    definer = root@localhost procedure sp_TongSLCuoiVatTu(IN p_id_vat_tu int, OUT p_tong_sl_cuoi int)
BEGIN
    SELECT SUM(sl_dau + tsl_nhap - tsl_xuat)
    INTO p_tong_sl_cuoi
    FROM ton_kho
    WHERE id_vat_tu = p_id_vat_tu;
END;

