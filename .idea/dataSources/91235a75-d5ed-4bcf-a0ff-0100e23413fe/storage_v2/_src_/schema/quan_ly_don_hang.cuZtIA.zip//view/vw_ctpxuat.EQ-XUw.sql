create definer = root@localhost view vw_ctpxuat as
select `px`.`id_phieu_xuat`                  AS `Số phiếu xuất hàng`,
       `ctpx`.`id_vat_tu`                    AS `Mã vật tư`,
       `ctpx`.`sl_xuat`                      AS `Số lượng xuất`,
       `ctpx`.`dg_xuat`                      AS `Đơn giá xuất`,
       (`ctpx`.`sl_xuat` * `ctpx`.`dg_xuat`) AS `Thành tiền xuất`
from (`quan_ly_don_hang`.`ct_phieu_xuat` `ctpx` join `quan_ly_don_hang`.`phieu_xuat` `px`
      on ((`ctpx`.`id_phieu_xuat` = `px`.`id_phieu_xuat`)));

